<?php 
    $user = "akrom";
    $pass = "123";
    if ($user == "akrom" && $pass == "123") {
        echo "Login Berhasil";
    } else {
        echo "Login Gagal";
    }
?>