<?php
    $nilai = 50;
    if ($nilai >= 60) {
        echo "Nilai Anda $nilai, Anda Lulus";
    } else {
        echo "Nilai Anda $nilai, Anda Gagal";
    }

?>