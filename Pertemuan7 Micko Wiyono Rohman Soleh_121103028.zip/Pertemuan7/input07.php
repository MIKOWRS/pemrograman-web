<html>
    <head><title>Band Favorit ~ Inputan Checkbox</title></head>
    <body>
        <FORM ACTION="proses07.php" METHOD="POST" NAME="input">
            <h2>Pilih Band Favorit Anda :</h2>
            <input type="checkbox" name="band01" value="Ada band"
checked>Ada band<br>
            <input type="checkbox" name="band02" value="Sheila on 7"
>Sheila on 7<br>
            <input type="checkbox" name="band03" value="Ungu"
>Ungu<br>
            <input type="checkbox" name="band04" value="Dewa 19"
>Dewa 19<br>
            <input type="submit" name="Pilih" value="Pilih">
        </FORM>
    </body>
</html>



