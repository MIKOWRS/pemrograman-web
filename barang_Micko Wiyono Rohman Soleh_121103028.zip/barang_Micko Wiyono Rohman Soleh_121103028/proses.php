<?php
include 'koneksi.php';
if(isset($_POST['btnProses'])){
    $nama_barang=$_POST['nama_barang'];
    $unit=$_POST['unit'];
    $merek=$_POST['merek'];
    $kategori=$_POST['kategori'];

    $gambar=$_FILES['gambar']['name'];
    echo $gambar;
    die();

    if($_POST['btnProses']=="tambah"){

        $gambar=$_FILES['gambar']['name'];
        $dir="gambar/"
        ['gambar']['tmp_name'];
        move_uploaded_file($dirfile, $dir . $gambar);
       
        $query = "INSERT INTO tb_barang VALUES('', '$nama_barang', '$unit', '$merek','$kategori','$gambar')";
        $sql =mysqli_query($konek,$query);
        if ($sql) {
            header('location:index.php');
        }
    }else {
        echo "edit data";
    }
}   elseif ($_GET['hapus']){
    $query = "DELETE FROM tb_barang WHERE id='$_GET[hapus]'";
    $sql = mysqli_query($konek, $query);
    if ($sql){
        header('location:index.php');
    }
}

?>