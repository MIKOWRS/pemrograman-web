<?php
    if (isset($_GET['input'])) {
        $nama = $_GET['nama'] ;
        echo "Nama Anda : <b>$nama</b>";
    }
?>