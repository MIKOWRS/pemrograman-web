<html>
    <head><title>Pengolahan Form</title></head>
    <body>
        <form action="proses02.php" method="post" name="input">
            Nama Anda : <input type="text" name="nama"><br>
            <input type="submit" name="Input" value="Input">
        </form>
    </body>
</html>