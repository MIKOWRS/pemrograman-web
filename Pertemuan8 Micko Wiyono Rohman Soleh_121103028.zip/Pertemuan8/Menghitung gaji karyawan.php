<html>
<head>
<title>hitung gaji karyawan</title>
</head>

<body>
<h1>Perhitungan Upah Karyawan</h1>
<form id=”form1″ name=”form1″ method=”post” action=”gajikaryawan.php”>
<table width=”401″ height=”117″ >
<tr>
<td width=”142″>Nama Karyawan : </td>
<td width=”243″><label>
<input name=”nama” type=”text” size=”35″ />
</label></td>
</tr>
<tr>
<td>Jam Kerja : </td>
<td><label>
<input type=”text” name=”jam”/>
</label></td>
</tr>
<tr>
<td></td>
<td><label>
<input type=”submit” name=”submit” value=”Submit” />
<input type=”reset” name=”hapus” value=”Hapus” />
</label></td>
</tr>
</table>
</form>
</body>
</html>