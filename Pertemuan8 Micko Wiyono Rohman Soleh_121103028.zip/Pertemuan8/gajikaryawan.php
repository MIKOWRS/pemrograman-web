<?php
if ($_POST['jam'] <= 48)
{
    $nama = $_POST['nama'];
    $jam = $_POST['jam'];
    $gaji = $jam * 2000;
    $bonus = 0; // calculate bonus here
    $tunjangan = $gaji; // calculate tunjangan here
    $pajak = 0; // calculate pajak here
    
    echo "Nama Karyawan: " . $nama . "<br>";
    echo "Gaji Karyawan: " . $gaji . "<br>";
    echo "Bonus: " . $bonus . "<br>";
    echo "Tunjangan: " . $tunjangan . "<br>";
    echo "Pajak: " . $pajak . "<br>";
    echo "Total Gaji: " . ($gaji + $bonus + $tunjangan - $pajak) . "<br>";
}
else if ($_POST['jam'] > 48)
{
    $nama = $_POST['nama'];
    $jam = $_POST['jam'];
    $jamsisa = $jam - 48;
    $gaji = 48 * 2000;
    $lembur = $jamsisa * 3000;
    $bonus = 0; // calculate bonus here
    $tunjangan = $gaji + $lembur; // calculate tunjangan here
    $pajak = 0; // calculate pajak here
    
    echo "Nama Karyawan: " . $nama . "<br>";
    echo "Gaji Karyawan: " . $gaji . "<br>";
    echo "Upah Lembur: " . $lembur . "<br>";
    echo "Bonus: " . $bonus . "<br>";
    echo "Tunjangan: " . $tunjangan . "<br>";
    echo "Pajak: " . $pajak . "<br>";
    echo "Total Gaji: " . ($gaji + $lembur + $bonus + $tunjangan - $pajak) . "<br>";
}
?>